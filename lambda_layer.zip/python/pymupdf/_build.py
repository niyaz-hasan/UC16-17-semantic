mupdf_location='https://mupdf.com/downloads/archive/mupdf-1.26.2-source.tar.gz'
